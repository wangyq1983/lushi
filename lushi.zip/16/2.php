﻿<?php
	$img = imagecreatetruecolor(300, 200);	            //创建一个300*200的画布
	echo imagesx($img);                              	//输出画布宽度300   
	echo imagesy($img);                              	//输出画布高度200

