module.exports = 'require/subdir2/loader'
