var a = require('./a');
exports.a = a;
