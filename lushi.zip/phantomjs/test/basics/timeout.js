//! no-harness
//! expect-exit: -15
//! expect-stderr: TIMEOUT: Process terminated after 0.25 seconds.
//! timeout: 0.25

// no code, so phantom will just sleep forever
