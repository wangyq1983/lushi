This project contains the **Linenoise project**, initially released
by [Salvatore Sanfilippo](https://github.com/antirez). Here we import a fork
by [Tad Marshall](https://github.com/tadmarshall) that lives at
[github.com/tadmarshall/linenoise](https://github.com/tadmarshall/linenoise).

The version of Linenoise included in PhantomJS refers to the commit:
-----
commit 7946e2c2d08df11dca2b99c5db40360c3d3e9a80
Author: Alan T. DeKok <aland@freeradius.org>
Date:   Wed Oct 26 15:56:52 2011 +0200

    Added character callbacks again
-----

Some files not needed for PhantomJS are removed.

Linenoise is licensed under the BSD-license.
Kudos to all the developers that contribute to this nice little pearl.
